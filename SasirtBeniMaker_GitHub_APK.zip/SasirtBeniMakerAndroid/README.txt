ŞAŞIRT BENİ MAKER - ANDROID

Android Studio ile açılabilir gerçek Android uygulama projesidir.
Özellik: konu seçimi, rastgele konu, süre/dil seçimi, tek tuşla brief oluşturma,
Android panosuna otomatik kopyalama ve ViewMade create sayfasını açma.

APK oluşturmak için Android Studio'da projeyi açıp Build > Build APK(s) seçin.
