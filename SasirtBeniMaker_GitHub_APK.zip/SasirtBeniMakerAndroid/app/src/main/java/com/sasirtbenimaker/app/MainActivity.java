package com.sasirtbenimaker.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    EditText topic; Spinner kind,duration,language; TextView preview,status;
    String[] kinds={"İlginç Bilgiler","Gizemli Olaylar","Tarih","Bilim","Uzay","Psikoloji"};
    String[] durations={"30-45 saniye","20-30 saniye","45-60 saniye"};
    String[] languages={"Türkçe","English","Español","Deutsch"};
    String[][] topics={
        {"İnsan beyninin yapabildiği şaşırtıcı bir şey","Dünyadaki en garip hayvan özelliği","Günlük hayatta fark etmediğimiz inanılmaz gerçek"},
        {"Tarihin en gizemli çözülemeyen olayı","Gerçek olduğu kanıtlanan tuhaf olay","Dünyanın en garip kayboluş vakası"},
        {"Tarihin en şaşırtıcı tesadüfü","Bir ülkenin kaderini değiştiren inanılmaz olay"},
        {"Bilimin açıkladığı en şaşırtıcı gerçek","Vücudumuz hakkında inanılmaz gerçek"},
        {"Evren hakkında çoğu insanın bilmediği gerçek","Uzayda gerçekleşen inanılmaz olay"},
        {"Beynimizin bizi kandırdığı şaşırtıcı durum","Hafızamızla ilgili çoğu kişinin bilmediği gerçek"}
    };

    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        topic=findViewById(R.id.topic); kind=findViewById(R.id.kind); duration=findViewById(R.id.duration);
        language=findViewById(R.id.language); preview=findViewById(R.id.preview); status=findViewById(R.id.status);
        setup(kind,kinds); setup(duration,durations); setup(language,languages);
        findViewById(R.id.random).setOnClickListener(v -> {
            int k=kind.getSelectedItemPosition();
            topic.setText(topics[k][new Random().nextInt(topics[k].length)]);
            update();
        });
        findViewById(R.id.copy).setOnClickListener(v -> copy(false));
        findViewById(R.id.create).setOnClickListener(v -> copy(true));
        update();
    }
    void setup(Spinner s,String[] a){s.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,a));}
    String brief(){
        String t=topic.getText().toString().trim();
        if(t.isEmpty()) t=topics[kind.getSelectedItemPosition()][0];
        return "Create a viral YouTube Short in "+language.getSelectedItem()+"\\n"+
        "Niche: "+kind.getSelectedItem()+"\\nTopic: "+t+"\\nLength: "+duration.getSelectedItem()+
        "\\n\\nStart with an extremely strong 1-2 second hook that creates curiosity. "+
        "Use fast narration, short sentences and frequent visual changes. Use accurate information. "+
        "Create the complete vertical 9:16 short with narration, suitable visuals, burned-in captions, title, description and tags. "+
        "End with a memorable fact or curiosity-driven CTA.";
    }
    void update(){ preview.setText(brief()); }
    void copy(boolean open){
        String b=brief();
        ((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE))
          .setPrimaryClip(ClipData.newPlainText("ViewMade Brief",b));
        status.setText("✓ Brief otomatik olarak kopyalandı.");
        if(open) startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://viewmade.com/dashboard/create")));
    }
}
