ŞAŞIRT BENİ MAKER — OTOMATİK APK

1) Bu klasörü GitHub'da yeni bir repository'ye yükle.
2) GitHub'da Actions sekmesine gir.
3) "Build Android APK" iş akışını seç.
4) "Run workflow" düğmesine bas. (main branch seçili olsun.)
5) İşlem bitince ilgili çalıştırmaya gir.
6) Artifacts bölümünden "SasirtBeniMaker-debug-apk" dosyasını indir.
7) ZIP'i açıp app-debug.apk dosyasını Android telefona aktar ve kur.

Not: Bu workflow debug APK üretir; Google Play'e yayınlamak için imzalı release build gerekir.
